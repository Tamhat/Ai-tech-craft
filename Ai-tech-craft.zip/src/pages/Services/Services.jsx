
import Service from "../../component/service/Service";
import RequestSubmit from "../../shared/RequestSubmit/RequestSubmit";

const Services = () => {
  return (
    <div> 
      <Service />
      <RequestSubmit />
      </div>
  )
}

export default Services