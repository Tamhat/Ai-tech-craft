
import './BannerVideo.css'

const BannerVideo = () => {
  return (
    <section>
        <div className="container bVideoContainer">
            <video src="https://comradeweb.com/wp-content/uploads/2022/06/Comrade-Showreel-V3.m4v" autoPlay muted />
        </div>
    </section>
  )
}

export default BannerVideo