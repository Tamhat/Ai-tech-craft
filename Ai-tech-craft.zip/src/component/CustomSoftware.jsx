import React from 'react'

const CustomSoftware = () => {
  return (
    <div>CustomSoftware</div>
  )
}

export default CustomSoftware